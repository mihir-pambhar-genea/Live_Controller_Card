# SCP Live Tracker (GitHub Pages)

This repo is structured for GitHub Pages using the **/docs** folder.

- Put your static site files in `docs/`.
- Enable GitHub Pages: Settings → Pages → Source = `main` / `/docs`.

The app is a single-file front-end at `docs/index.html`.
